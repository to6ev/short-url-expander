<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="shortcut icon" href="shortURLong.png" />
    <meta charset="utf-8">
    <meta name="description" content="Decode Tiny URL">
    <meta name="keywords" content="decode tiny url, expand url, decode short url"/>
    <meta name="author" content="ETI Free Stuff - www.eti.pw">
    <meta name="robots" content="all"/>
    <title>TinyURL Decoder API</title>
    <link href="style.css" rel="stylesheet">
</head>

<body>

    <div id="top" class="header">
        <div class="vert-text">
            <h1>TinyURL Decoder API<a href="./"></a></h1>
            <h2>
<em>
Decode a TinyURL (Short URL - Shrink URL - Shortener URL)<br />
Short URL to Original URL<br />
Find out where Short URL link is really taking you!<br />
</em>
            </h2>
<p>|<a href='index.php' title="Expand Short URL">Expand</a>|<a href='about.php'>About</a>|<a href='services.php' title="Services about Tiny URL">Services</a>|<a href='download.php' title="Get source code of this php project">Get src</a>|</p>

<b>API</b><br />
<br />
With simple GET Method<br>
<br>
<li>If you want to get only long url (original link) output:</li>
<br>
http://longurl.eti.pw/u?u=<br>
<br>
e.g. http://longurl.eti.pw/u?u=http://eti.hol.es/81<br>
<br>
And the Result is: <br />
<br />
http://imgu.bl.ee/i/c7fed383ed3e889c83d38ec7b9e26ad3.png<br>
<br>
<li>If you want more outputs, then use:</li>
<br>
http://longurl.eti.pw/s?s=<br>
<br>
e.g. http://longurl.eti.pw/s?s=http://eti.hol.es/81<br />
<br />
And the result will be:<br>
<br>
Short URL: http://eti.hol.es/81<br>
Original URL(Long URL) is: http://imgu.bl.ee/i/c7fed383ed3e889c83d38ec7b9e26ad3.png<br>
Virus check: Scan link<br>
<br>
<br>
Well, this is. You can get src too or HTML form below.
 
<br />
<hr>
Link To US:<br>
<p>You can use this form in your website:</p>
<form action="http://longurl.eti.pw" method="get" target="_blank">
<table align="center" cellpadding="5" bgcolor="#E7E7F7"><tr><td>
<small><b>Expand <a href="http://longurl.eti.pw" target="_blank">Short URL:</a></b></small>
<input type="text" name="url" size="30"><input type="submit" value="Expand TinyURL">
</td></tr></table>
</form>
<br>
<p>Get HTML code:</p>
<p>Copy&Paste the code of the page you want in your site. That's all! You already have a form for TinyURL Expander.</p>
<br />
<textarea style="color: blue; background-color: transparent" rows="17" cols="37" onclick="this.select()" readonly >
<!-- Expand TinyURL BEGIN CODE-->
<form action="http://longurl.eti.pw" method="get" target="_blank">
<table align="center" cellpadding="5" bgcolor="#E7E7F7"><tr><td>
<small><b>Expand <a href="http://longurl.eti.pw" target="_blank">Short URL:</a></b></small>
<input type="text" name="url" size="30"><input type="submit" value="Expand TinyURL">
</td></tr></table>
</form>
<!-- Expand TinyURL END CODE-->
</textarea>

      </div>
    </div>
    
<br />
<hr>
<center>
<!-- Webcounter BEGIN CODE-->
<small><a href="http://webcounter.bl.ee" title="Free Web Counter" target="_blank">Own Free Web Counter Service Script - Open Source</a></small><br />
<script language="Javascript" src="http://webcounter.bl.ee/counter.php?page=2a23bb3"></script><br />
<!-- Webcounter END CODE-->
<a href="http://eti.pw" target="_blank" title="Free Web Design and Hosting">ETI</a>
</center>
      
</body>
</html>
