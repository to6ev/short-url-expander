<!DOCTYPE html>
<html lang="en">
<head>
    <title>TinyURL Decoder Src</title>
    <link rel="shortcut icon" href="shortURLong.png" />
    <meta charset="utf-8">
    <meta name="description" content="Decode Tiny URL">
    <meta name="keywords" content="url expand source code, expand url src, short url to long url code, decode tiny url, expand url, decode short url"/>
    <meta name="author" content="ETI Free Stuff - www.eti.pw">
    <meta name="robots" content="all"/>
    <link href="style.css" rel="stylesheet">
</head>

<body>

    <div id="top" class="header">
        <div class="vert-text">
            <h1>TinyURL Decoder <a href="./"></a></h1>
            <h2>
<em>
Decode a TinyURL (Short URL - Shrink URL - Shortener URL)<br />
Short URL to Original URL<br />
Find out where Short URL link is really taking you!<br />
</em>
            </h2>
<p>|<a href='index.php'>Expand</a>|<a href='about.php'>About</a>|<a href='services.php'>Services</a>|<a href='api.php'>API</a>|<a href='download.php'>Get src</a>|</p>

<b>Get Source code - Download this project</b><br />
<br />

<b><a href='eti-expand-short-url-src.zip' target='_blank'>|Grab Source code - DOWNLOAD|</a></b>
 
<br />
<hr>
Link To US:<br>
<p>You can use this form in your website:</p>
<form action="http://longurl.eti.pw" method="get" target="_blank">
<table align="center" cellpadding="5" bgcolor="#E7E7F7"><tr><td>
<small><b>Expand <a href="http://longurl.eti.pw" target="_blank">Short URL:</a></b></small>
<input type="text" name="url" size="30"><input type="submit" value="Expand TinyURL">
</td></tr></table>
</form>
<br>
<p>Get HTML code:</p>
<p>Copy&Paste the code of the page you want in your site. That's all! You already have a form for TinyURL Expander.</p>
<br />
<textarea style="color: blue; background-color: transparent" rows="17" cols="37" onclick="this.select()" readonly >
<!-- Expand TinyURL BEGIN CODE-->
<form action="http://longurl.eti.pw" method="get" target="_blank">
<table align="center" cellpadding="5" bgcolor="#E7E7F7"><tr><td>
<small><b>Expand <a href="http://longurl.eti.pw" target="_blank">Short URL:</a></b></small>
<input type="text" name="url" size="30"><input type="submit" value="Expand TinyURL">
</td></tr></table>
</form>
<!-- Expand TinyURL END CODE-->
</textarea>

      </div>
    </div>
<hr>  
<center>
<!-- Webcounter BEGIN CODE-->
<small><a href="http://webcounter.bl.ee" title="Free Web Counter" target="_blank">Own Free Web Counter Service Script - Open Source</a></small><br />
<script language="Javascript" src="http://webcounter.bl.ee/counter.php?page=2a23bb3"></script><br />
<!-- Webcounter END CODE-->
<a href="http://eti.pw" target="_blank" title="Free Web Design and Free Web Hosting">ETI</a>
</center>
      
</body>
</html>
