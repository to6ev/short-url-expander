<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="shortcut icon" href="shortURLong.png" />
    <meta charset="utf-8">
    <meta name="description" content="Decode Tiny URL">
    <meta name="keywords" content="decode tiny url, expand url, decode short url"/>
    <meta name="author" content="ETI Free Stuff - www.eti.pw">
    <meta name="robots" content="all"/>
    <title>TinyURL Decoder</title>
    <link href="style.css" rel="stylesheet">
</head>

<body>

    <div id="top" class="header">
        <div class="vert-text">
            <h1>TinyURL Decoder <a href="./"></a></h1>
            <h2>
<em>
Decode a TinyURL (Short URL - Shrink URL - Shortener URL)<br />
Short URL to Original URL<br />
Find out where Short URL link is really taking you!<br />
</em>
            </h2>
<p>|<a href='index.php'>Expand</a>|<a href='about.php'>About</a>|<a href='services.php'>Services</a>|<a href='api.php'>API</a>|<a href='download.php'>Get src</a>|</p>

<b>About Short URL Decoder</b><br />
<br />
TinyURL.com and other like services solved a problem brought on by the advent of micro-blogging—limited message length. They do this by taking (sometimes incredibly long) URLs and creating a small compact one that redirects to the original.<br />

Solving one problem, though created another one: obfuscation. There's no way to tell where a shortened link goes by just looking at it. So, then, I could send you this link http://is.gd/IJjgxa (it's youtube video) and tell you to check out the video or pics from my recent trip, or other, when in fact I'm sending you to any website with Viruses or Ads(advertising). This is bad for users.<br />

To help with the situation many URL shortening services provide some sort of "preview" feature that lets you see where a link will take you before actually going there. But, yet again, this creates another problem. With so many URL shortening services, each with their own way of previewing URLs, it would be troublesome for developers to try and support a preview feature for all the services. This is where www.LongURL.eti.pw comes in :)<br />
 
<br />

      </div>
    </div>
    
<br />
<hr>
<center>
<!-- Webcounter BEGIN CODE-->
<small><a href="http://webcounter.bl.ee" title="Free Web Counter" target="_blank">Own Free Web Counter Service Script - Open Source</a></small><br />
<script language="Javascript" src="http://webcounter.bl.ee/counter.php?page=2a23bb3"></script><br />
<!-- Webcounter END CODE-->
<a href="http://eti.pw" target="_blank" title="Free Web Design and Hosting">ETI</a>
</center>
      
</body>
</html>
