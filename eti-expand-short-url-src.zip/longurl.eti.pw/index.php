<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="shortcut icon" href="shortURLong.png" />
    <meta charset="utf-8">
    <meta name="description" content="Decode Tiny URL">
    <meta name="keywords" content="expand short url, decode tiny url, expand url, decode short url, url expand, tiny url decoder, tinyurl decoder, short url decoder, url expander"/>
    <meta name="author" content="ETI Dev - www.eti.pw">
    <meta name="robots" content="all"/>
    <title>TinyURL Decoder</title>
    <link href="style.css" rel="stylesheet">
</head>

<body>

    <div id="top" class="header">
        <div class="vert-text">
            <a href="./">| Expand Short URL |</a>
            <h1>URL Expand | TinyURL Decoder</h1>
            <h2>
<em>
Decode a TinyURL (Short URL - Shrink URL - Shortener URL)<br />
Short URL to Original URL<br />
Find out where Short URL link is really taking you!<br />
</em>
            </h2>
<p>|<a href='about.php'>About</a>|<a href='services.php'>Services</a>|<a href='api.php'>API</a>|<a href='download.php' title="Get Source code of this project">Get src</a>|</p>
<i>Expand URL</i><br />
<form method="GET" action="">
Enter short URL: 
<input type="text" name="url" id="url" style="width:300px;height:40px;" value="http://" placeholder="Enter short URL" title="Enter short URL" />
<input type="submit" style="width:200px;height:40px;color:blue" value="Show Original URL" />
</form>  
Get information on a short URL. Find out where it goes!<br />

<?php
$url            = htmlentities($_GET['url'], ENT_QUOTES, 'UTF-8');
$original_url   = get_original_url($url);
$htmlsrc = file_get_contents($_GET['url']);

echo "<font color='red'>Short URL:</font> {$url}<br/>";
echo "<font color='red'>Original URL(Long URL) is:</font> <a href='{$original_url}' target='_blank'>{$original_url}</a><br />";
echo "<font color='red'>Virus check:</font> <a href='https://www.google.com/transparencyreport/safebrowsing/diagnostic/index.html#url={$original_url}' target='_blank' title='Is this link safe?'>Scan link</a>";
 
function get_original_url($url)
{
    $ch = curl_init($url);
    curl_setopt($ch,CURLOPT_HEADER,true); 
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION,false);
    $header = curl_exec($ch);
    
    $fields = explode("\r\n", preg_replace('/\x0D\x0A[\x09\x20]+/', ' ', $header));
        
    for($i=0;$i<count($fields);$i++)
    {
        if(strpos($fields[$i],'Location') !== false)
        {
            $url = str_replace("Location: ","",$fields[$i]);
        }
    }
    return $url;
}
?>

<hr>

<i>Extra Info:</i> [See Meta tags: title, author, keywords, description, generator] and look HTML source code for something suspicious; See Website Screenshot below and then go to the website!<br />

<?php
$tags = get_meta_tags($_GET['url']);
echo "Meta tags: <br />";
echo "Title: ";
echo $tags['title'];  
echo "<br />"; 
echo "Author: ";    
echo $tags['author'];    
echo "<br />";   
echo "Keywords: ";    
echo $tags['keywords'];   
echo $tags['Keywords'];
echo $tags['KEYWORDS'];
echo "<br />"; 
echo "Description: ";    
echo $tags['description'];  
echo $tags['Description'];
echo $tags['DESCRIPTION'];
echo "<br />";
echo "Generator: ";    
echo $tags["generator"];
echo $tags["Generator"];
echo $tags["GENERATOR"];
echo "<br />";
?>
<br />
<center>
Website Screenshot:<br />

<?php
if(!empty($_GET['url'])){
    //website url
    $siteURL = $_GET['url'];

    if(filter_var($siteURL, FILTER_VALIDATE_URL)){
        //call Google PageSpeed Insights API
        $googlePagespeedData = file_get_contents("https://www.googleapis.com/pagespeedonline/v2/runPagespeed?url=$siteURL&screenshot=true");

        //decode json data
        $googlePagespeedData = json_decode($googlePagespeedData, true);

        //screenshot data
        $screenshot = $googlePagespeedData['screenshot']['data'];
        $screenshot = str_replace(array('_','-'),array('/','+'),$screenshot);

        //display screenshot image
        echo "<img src=\"data:image/jpeg;base64,".$screenshot."\" title='320px × 179px' />";

    }else{
        echo "Please enter a valid URL";
    }
}
?>

<?php
// <img src='http://images.shrinktheweb.com/xino.php?stwembed=1&stwaccesskeyid=93e93e229a837b8&stwsize=xlg&stwurl={$original_url}'/>
// echo "<iframe src='snap.php?url={$original_url}' width='330' height='200' FRAMEBORDER=NO FRAMESPACING=0 BORDER=0 ></iframe><br />";
// echo "<iframe src='http://free.pagepeeker.com/v2/thumbs.php?size=x&url={$original_url}' width='320' height='250' FRAMEBORDER=NO FRAMESPACING=0 BORDER=0 ></iframe>";
echo "<br /><a href='javascript:history.go(0)'><img src='http://free.pagepeeker.com/v2/thumbs.php?size=x&url={$original_url}' title='Refresh Image' /></a>";
?>
<br /><small>If you do not see the pictures, then 
<a href="javascript:history.go(0)">Click Here</a></small>
</center>

<hr>
 
<textarea readonly style="width:100%;color: red;background-color:transparent" rows="20">HTML src is here:
<?php
echo htmlspecialchars( $htmlsrc );
?>
</textarea>

      </div>
    </div>
<hr>  
<center>
<!-- Webcounter BEGIN CODE-->
<small><a href="http://webcounter.bl.ee" title="Free Web Counter like Service PHP Script" target="_blank">Own Free Web Counter Service Script - Open Source</a></small><br />
<script language="Javascript" src="http://webcounter.bl.ee/counter.php?page=2a23bb3"></script><br />
<!-- Webcounter END CODE-->
<a href="http://eti.pw" target="_blank" title="Free Web Design and Free Web Hosting">ETI</a>
</center>
      
</body>
</html>
