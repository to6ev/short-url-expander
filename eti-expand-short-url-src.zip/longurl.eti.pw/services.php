<!DOCTYPE html>
<html lang="en">
<head>
    <title>TinyURL Services</title>
    <link rel="shortcut icon" href="shortURLong.png" />
    <meta charset="utf-8">
    <meta name="description" content="All Tiny URLs">
    <meta name="keywords" content="decode tiny url, expand url, decode short url, all tiny url services, all tiny url sites"/>
    <meta name="author" content="ETI Free Stuff - www.eti.pw">
    <meta name="robots" content="all"/>
    <link href="style.css" rel="stylesheet">
</head>

<body>

    <div id="top" class="header">
        <div class="vert-text">
            <h1>TinyURL Decoder <a href="./"></a></h1>
            <h2>
<em>
Decode a TinyURL (Short URL - Shrink URL - Shortener URL)<br />
Short URL to Original URL<br />
Find out where Short URL link is really taking you!<br />
</em>
            </h2>
<p>|<a href='index.php'>Expand</a>|<a href='about.php'>About</a>|<a href='services.php'>Services</a>|<a href='api.php'>API</a>|<a href='download.php'>Get src</a>|</p>

<b>URL Shortening Services</b><br />
<br />

These are the URL shorteners we currently know of. LongURL.eti.pw is not limited to expanding only URLs from these services, however third-party applications often use this list to determine which URLs have been shortened.<br />
<br />      
<b>Service Domains</b>
                
<ol>
<li>0rz.tw</li>
<li>1link.in</li>
<li>1url.com</li>
<li>2.gp</li>
<li>2big.at</li>
<li>2tu.us</li>
<li>3.ly</li>
<li>307.to</li>
<li>4ms.me</li>
<li>4sq.com</li>
<li>5e0.in</li>
<li>4url.cc</li>
<li>6.ly</li>
<li>6url.com</li>
<li>7.ly</li>
<li>7s.pw</li>
<li>a.gg</li>
<li>a.nf</li>
<li>aa.cx</li>
<li>abcurl.net</li>
<li>ad.vu</li>
<li>adf.ly</li>
<li>adjix.com</li>
<li>afx.cc</li>
<li>all.fuseurl.com</li>
<li>alturl.com</li>
<li>amzn.to</li>
<li>ar.gy</li>
<li>arst.ch</li>
<li>atu.ca</li>
<li>azc.cc</li>
<li>b23.ru</li>
<li>b2l.me</li>
<li>bacn.me</li>
<li>bcool.bz</li>
<li>binged.it</li>
<li>bit.ly</li>
<li>bizj.us</li>
<li>bloat.me</li>
<li>bravo.ly</li>
<li>bsa.ly</li>
<li>budurl.com</li>
<li>canurl.com</li>
<li>chilp.it</li>
<li>chzb.gr</li>
<li>cl.lk</li>
<li>cl.ly</li>
<li>clck.ru</li>
<li>cli.gs</li>
<li>cliccami.info</li>
<li>clickthru.ca</li>
<li>clop.in</li>
<li>conta.cc</li>
<li>cort.as</li>
<li>cot.ag</li>
<li>crks.me</li>
<li>ctvr.us</li>
<li>cutt.us</li>
<li>dai.ly</li>
<li>decenturl.com</li>
<li>dfl8.me</li>
<li>digbig.com</li>
<li>digg.com</li>
<li>disq.us</li>
<li>dld.bz</li>
<li>dlvr.it</li>
<li>do.my</li>
<li>doiop.com</li>
<li>dopen.us</li>
<li>e7.al</li>
<li>easyuri.com</li>
<li>easyurl.net</li>
<li>eepurl.com</li>
<li>eweri.com</li>
<li>fa.by</li>
<li>fav.me</li>
<li>fb.me</li>
<li>fbshare.me</li>
<li>ff.im</li>
<li>fff.to</li>
<li>fire.to</li>
<li>firsturl.de</li>
<li>firsturl.net</li>
<li>flic.kr</li>
<li>flq.us</li>
<li>fly2.ws</li>
<li>fon.gs</li>
<li>freak.to</li>
<li>fuseurl.com</li>
<li>fuzzy.to</li>
<li>fwd4.me</li>
<li>fwib.net</li>
<li>g.ro.lt</li>
<li>gizmo.do</li>
<li>gl.am</li>
<li>go.9nl.com</li>
<li>go.ign.com</li>
<li>go.usa.gov</li>
<li>goo.gl</li>
<li>goshrink.com</li>
<li>gurl.es</li>
<li>hex.io</li>
<li>hiderefer.com</li>
<li>hmm.ph</li>
<li>href.in</li>
<li>hsblinks.com</li>
<li>htxt.it</li>
<li>huff.to</li>
<li>hulu.com</li>
<li>hurl.me</li>
<li>hurl.ws</li>
<li>icanhaz.com</li>
<li>idek.net</li>
<li>ilix.in</li>
<li>is.gd</li>
<li>its.my</li>
<li>ix.lt</li>
<li>j.mp</li>
<li>jar.ma</li>
<li>jijr.com</li>
<li>kl.am</li>
<li>klck.me</li>
<li>korta.nu</li>
<li>krunchd.com</li>
<li>l9k.net</li>
<li>lat.ms</li>
<li>liip.to</li>
<li>liltext.com</li>
<li>linkbee.com</li>
<li>linkbun.ch</li>
<li>liurl.cn</li>
<li>ln-s.net</li>
<li>ln-s.ru</li>
<li>lnk.gd</li>
<li>lnk.ms</li>
<li>lnkd.in</li>
<li>lnkurl.com</li>
<li>lru.jp</li>
<li>lt.tl</li>
<li>lurl.no</li>
<li>macte.ch</li>
<li>mash.to</li>
<li>merky.de</li>
<li>migre.me</li>
<li>miniurl.com</li>
<li>minurl.fr</li>
<li>mke.me</li>
<li>moby.to</li>
<li>moourl.com</li>
<li>mrte.ch</li>
<li>myloc.me</li>
<li>myurl.in</li>
<li>n.pr</li>
<li>nbc.co</li>
<li>nblo.gs</li>
<li>nn.nf</li>
<li>not.my</li>
<li>notlong.com</li>
<li>nsfw.in</li>
<li>nutshellurl.com</li>
<li>nxy.in</li>
<li>nyti.ms</li>
<li>o-x.fr</li>
<li>oc1.us</li>
<li>om.ly</li>
<li>omf.gd</li>
<li>omoikane.net</li>
<li>on.cnn.com</li>
<li>on.mktw.net</li>
<li>onforb.es</li>
<li>orz.se</li>
<li>ow.ly</li>
<li>ping.fm</li>
<li>pli.gs</li>
<li>pnt.me</li>
<li>politi.co</li>
<li>post.ly</li>
<li>pp.gg</li>
<li>profile.to</li>
<li>ptiturl.com</li>
<li>pub.vitrue.com</li>
<li>qlnk.net</li>
<li>qte.me</li>
<li>qu.tc</li>
<li>qy.fi</li>
<li>r.im</li>
<li>rb6.me</li>
<li>read.bi</li>
<li>readthis.ca</li>
<li>reallytinyurl.com</li>
<li>redir.ec</li>
<li>redirects.ca</li>
<li>redirx.com</li>
<li>retwt.me</li>
<li>ri.ms</li>
<li>rickroll.it</li>
<li>riz.gd</li>
<li>rt.nu</li>
<li>ru.ly</li>
<li>rubyurl.com</li>
<li>rurl.org</li>
<li>rww.tw</li>
<li>s4c.in</li>
<li>s7y.us</li>
<li>safe.mn</li>
<li>sameurl.com</li>
<li>sdut.us</li>
<li>shar.es</li>
<li>shink.de</li>
<li>shorl.com</li>
<li>short.ie</li>
<li>short.to</li>
<li>shortlinks.co.uk</li>
<li>shorturl.com</li>
<li>shout.to</li>
<li>show.my</li>
<li>shrinkify.com</li>
<li>shrinkr.com</li>
<li>shrt.fr</li>
<li>shrt.st</li>
<li>shrten.com</li>
<li>shrunkin.com</li>
<li>simurl.com</li>
<li>slate.me</li>
<li>smallr.com</li>
<li>smsh.me</li>
<li>smurl.name</li>
<li>sn.im</li>
<li>snipr.com</li>
<li>snipurl.com</li>
<li>snurl.com</li>
<li>sp2.ro</li>
<li>spedr.com</li>
<li>srnk.net</li>             
<li>srs.li</li>
<li>starturl.com</li>
<li>su.pr</li>
<li>surl.co.uk</li>
<li>surl.hu</li>
<li>t.cn</li>
<li>t.co</li>
<li>t.lh.com</li>
<li>ta.gd</li>
<li>tbd.ly</li>
<li>tcrn.ch</li>
<li>tgr.me</li>
<li>tgr.ph</li>
<li>tighturl.com</li>
<li>tiniuri.com</li>
<li>tiny.cc</li>
<li>tiny.ly</li>
<li>tiny.pl</li>
<li>tiny.my</li>
<li>tinylink.in</li>
<li>tinyuri.ca</li>
<li>tinyurl.com</li>
<li>tl.gd</li>
<li>tmi.me</li>
<li>tnij.org</li>
<li>tnw.to</li>
<li>tny.com</li>
<li>to.ly</li>
<li>togoto.us</li>
<li>totc.us</li>
<li>toysr.us</li>
<li>tpm.ly</li>
<li>tr.im</li>
<li>tra.kz</li>
<li>trunc.it</li>
<li>twhub.com</li>
<li>twirl.at</li>
<li>twitclicks.com</li>
<li>twitterurl.net</li>
<li>twitterurl.org</li>
<li>twiturl.de</li>
<li>twurl.cc</li>
<li>twurl.nl</li>
<li>u.mavrev.com</li>
<li>u.nu</li>
<li>u76.org</li>
<li>ub0.cc</li>
<li>ulu.lu</li>
<li>updating.me</li>
<li>ur1.ca</li>
<li>url.az</li>
<li>url.co.uk</li>
<li>url.ie</li>
<li>url360.me</li>
<li>url4.eu</li>
<li>urlborg.com</li>
<li>urlbrief.com</li>
<li>urlcover.com</li>
<li>urlcut.com</li>
<li>urlenco.de</li>
<li>urli.nl</li>
<li>urls.im</li>
<li>urlx.ie</li>
<li>urlzen.com</li>
<li>usat.ly</li>
<li>use.my</li>
<li>v.gd</li>
<li>vb.ly</li>
<li>vgn.am</li>
<li>vl.am</li>
<li>vm.lc</li>
<li>w55.de</li>
<li>wapo.st</li>
<li>wapurl.co.uk</li>
<li>wipi.es</li>
<li>wp.me</li>
<li>x.vu</li>
<li>xr.com</li>
<li>xref.pw</li>
<li>xrl.in</li>
<li>xrl.us</li>
<li>xurl.es</li>
<li>xurl.jp</li>
<li>y.ahoo.it</li>
<li>yatuc.com</li>
<li>ye.pe</li>
<li>yep.it</li>
<li>yfrog.com</li>
<li>yhoo.it</li>
<li>yiyd.com</li>
<li>youtu.be</li>
<li>yourl.su</li>
<li>yuarel.com</li>
<li>z0p.de</li>
<li>zi.ma</li>
<li>zi.mu</li>
<li>zipmyurl.com</li>
<li>zud.me</li>
<li>zurl.ws</li>
<li>zz.gd</li>
<li>zzang.kr</li>
</ol>
     
<br />

You don't see your URL here? OK tell Us: 
<form method="post" action="addurl.php" target="_blank">
   <input type="text" name="url" id="url" style="width:300px;height:40px;" placeholder="Enter Short URL service" />
   <input type="submit" style="width:200px;height:40px;color:blue" value="Add your TinyURL Service" />
</form>  

<br>
      </div>
    </div>
<hr>
<center>
<!-- Webcounter BEGIN CODE-->
<small><a href="http://webcounter.eti.pw" title="Free Web Counter" target="_blank">Own Free Web Counter Service Script - Open Source</a></small><br />
<script language="Javascript" src="http://webcounter.eti.pw/counter.php?page=2a23bb3"></script><br />
<!-- Webcounter END CODE-->
<a href="http://eti.pw" target="_blank" title="Free Web Design and Free Web Hosting">ETI</a>
</center>
      
</body>
</html>
