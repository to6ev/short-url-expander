<?php
	
$file = 'links.txt';

$data = htmlentities($_POST["url"]);

file_put_contents($file, "\n". $data, FILE_APPEND);

echo "$data added! thanx!<br />";
echo "After a few days your URL will be added in the list.";

?>
